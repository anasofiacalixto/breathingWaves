//// Breathing waves of mythic light by Ana Sofia Calixto
//// based on code by Daniel Shiffman 
//// https://thecodingtrain.com/CodingChallenges/011-perlinnoiseterrain.html
//// instructions: press any key to observe the waves growing, and again to go back to the initial state


// declare variables for the columns and rows in the waves grid
var cols, rows;

// set the scale of the waves
var scl = 40; // adjusted for a wider scale to fit the 5 screens without deforming the waves

// set the width and height of the canvas according to G05 size
var w = 9600;
var h = 1080;

// initialize a variable for the "flying" effect and set the initial maximum waves height
var flying = 0;
var maxWavesHeight = 180; // initial value for the maximum waves height

// variable to control when to start increasing maxWavesHeight
// if it's not "flying", it starts to do so, and the waves gradually get higher
// if it's already "flying", it stops, and the waves gradually get shorter
var increaseHeight = false;

// 2D array to store the heights of each point in the waves grid
var waves = [];

// setup function runs once at the beginning
function setup() {
  // create a canvas with WebGL rendering
  createCanvas(windowWidth, windowHeight, WEBGL);

  // calculate the number of columns and rows based on the scale and canvas dimensions
  cols = w / scl;
  rows = h / scl;

  // set stroke color filling shapes
  stroke(0, 15);
  noFill();

  // initialize the 2D array for waves heights
  for (var x = 0; x < cols; x++) {
    waves[x] = [];
  }
}

// draw function runs continuously to update the canvas
function draw() {
  // set the background color
  background(0);

  // increment the "flying" variable to create a moving effect
  flying -= 0.01;
  var yoff = flying;

  // set up transformations to create a 3D perspective
  noFill();
  translate(0, 250);
  rotateX(PI / 3);
  translate(-w / 2, -h / 2);

  // generate waves using Perlin noise
  for (var y = 0; y < rows - 1; y++) {
    // set a random color for each horizontal line of the waves
    // gives the perspective of blinking, or constantly changing like water
    var lineColor = color(random(200, 255));
    stroke(lineColor);

    // set varying stroke width based on the row position
    // the closer, the thicker the line, to give the impression of a more profound landscape
    var strokeWidth = map(y, 0, rows - 1, 1, 5);
    strokeWeight(strokeWidth);

    // begin drawing a shape for each horizontal line
    beginShape();

    for (var x = 0; x < cols; x++) {
      // map the noise function to create varying waves heights
      waves[x][y] = map(noise(x * 0.1, yoff), 0, 1, -50, 80);
      waves[x][y + 1] = map(noise(x * 0.1, (y + 1) * 0.1, yoff), 0, 1, -50, maxWavesHeight);

      // gradually increase or decrease maxWavesHeight based on the variable
      if (increaseHeight && maxWavesHeight < 1000) {
        maxWavesHeight += 0.00009;
      } else if (!increaseHeight && maxWavesHeight > 180) {
        maxWavesHeight += 0.1;
      }

      // add a vertex for each point in the waves grid
      vertex(x * scl, (y + 1) * scl, waves[x][y + 1]);
    }

    // end the shape for the current horizontal line
    endShape();
  }

  // increment yoff to create animation in the "flying" effect
  yoff += 0.1;
}

// function to handle key press events
function keyPressed() {
  // reset the state of increaseHeight and maxWavesHeight when the key is pressed
  increaseHeight = !increaseHeight;
  if (!increaseHeight) {
    maxWavesHeight = 180;
  }
}

// function to resize the canvas when the window is resized
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}
